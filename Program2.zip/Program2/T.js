// Reference to the blog posts container
        const blogPostsContainer = document.getElementById('blog-posts');

        // Handle form submission
        document.getElementById('blog-form').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent page reload

            // Get form data
            const title = document.getElementById('title').value;
            const content = document.getElementById('content').value;

            // Create a new blog post element
            const blogPost = document.createElement('div');
            blogPost.classList.add('blog-post');

            blogPost.innerHTML = `
                <h2>${title}</h2>
                <p>${content}</p>
            `;

            // Append the new post to the container
            blogPostsContainer.appendChild(blogPost);

            // Clear the form
            document.getElementById('blog-form').reset();
        });
		
		function openForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}


document.getElementById('myForm').addEventListener('submit', function(event) {
    event.preventDefault();


    const email = document.getElementById('email').value;
    const psw = document.getElementById('psw').value;
    const errorMessage = document.getElementById('error-message');

    errorMessage.textContent = ''; // Clear previous error message

    if (email === '' || psw === '') {
        errorMessage.textContent = 'Please fill in both fields.';
        return;
    }

    if (email === 'admin@gmail.com' && psw === 'password123') {
        alert('Login successful!');
        // Redirect to another page or perform any other actions after successful login
    } else {
        errorMessage.textContent = 'Invalid username or password.';
    }
});
